import csv

# 定义标签转换映射
label_mapping = {
    'normal': '0',
    'attacker': '1',
    'victim': '2'
}

# 定义协议转换映射
proto_mapping = {
    'tcp': '0',
    'udp': '1'
}

input_filename = 'raw.csv'
output_filename = 'output.csv'

# 定义需要提取的列索引（0-based）
COLUMNS = {
    'srcip': 0,
    'dstip': 1,
    'srcport': 2,
    'dstport': 3,
    'proto': 4,
    'ts': 5,
    'pkt': 7,    # pkt在第8列（索引7）
    'byt': 8,    # byt在第9列（索引8）
    'label': 9   # label在第10列（索引9）
}

with open(input_filename, 'r') as infile, open(output_filename, 'w', newline='') as outfile:
    csv_reader = csv.reader(infile)
    csv_writer = csv.writer(outfile)
    
    # 写入新文件的表头（增加pkt列）
    csv_writer.writerow(['srcip', 'dstip', 'srcport', 'dstport', 'proto', 'ts', 'pkt', 'byt', 'label'])
    
    # 跳过原始文件的表头行
    next(csv_reader)
    
    for row in csv_reader:
        if len(row) < 11:  # 确保行有足够列
            continue
        
        # 提取所需字段
        srcip = row[COLUMNS['srcip']]
        dstip = row[COLUMNS['dstip']]
        srcport = row[COLUMNS['srcport']]
        dstport = row[COLUMNS['dstport']]
        ts = row[COLUMNS['ts']]
        pkt = row[COLUMNS['pkt']]  # 新增pkt字段
        byt = row[COLUMNS['byt']]
        
        # 转换协议类型（proto列）
        raw_proto = row[COLUMNS['proto']].strip().lower()
        proto = proto_mapping.get(raw_proto, '2')  # TCP->0, UDP->1, 其他->2
        
        # 转换标签
        raw_label = row[COLUMNS['label']].strip().lower()
        label = label_mapping.get(raw_label, '3')  # 正常->0, 攻击者->1, 受害者->2, 其他->3
        
        # 写入新行（增加pkt字段）
        csv_writer.writerow([srcip, dstip, srcport, dstport, proto, ts, pkt, byt, label])

print(f"文件处理完成，结果已保存至: {output_filename}")
