label那一列被处理成 0,1,2,3 分别代表源文件中的 normal, attacker, victim和其他
proto那一列被处理成 0，1,2 分别代表源文件中的 TCP UDP 和其他

首先我使用了 prase.py对 raw.csv进行了解析，保留了我们想要的数据，并且对单词做了如上转换，得到文件 input.csv

然后使用 gen_counter.py对解析后的 input.csv进行周期性统计，也就是生成粗粒度counter了，得到文件 output.csv

这两者就对应模型的输入输出，即由周期性的统计（counters）生成数据包序列

有一点需要注意，现在的output.csv中有label这一列。其实CLTM生成的数据包序列是没有label的，并且超分辨率也没理由能生成label，
但我们的下游任务测试需要做标签分类，所以最终还是要生成label。ZoomSynth中，我们用了奇技淫巧生成准确的label，这里干脆就让LLM尝试生成吧。
