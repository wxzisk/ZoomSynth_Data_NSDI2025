import csv
import argparse

def process_csv(input_file, output_file, time_window):
    with open(input_file, 'r') as infile, open(output_file, 'w', newline='') as outfile:
        csv_reader = csv.DictReader(infile)
        csv_writer = csv.writer(outfile)
        
        # 写入输出文件的表头
        csv_writer.writerow(['start_ts', 'end_ts', 'row_count', 'total_pkt', 'total_byt'])
        
        # 初始化统计变量
        first_row = next(csv_reader)
        start_ts = float(first_row['ts'])
        current_window_end = start_ts + time_window
        
        row_count = 1
        total_pkt = int(first_row['pkt'])
        total_byt = int(first_row['byt'])
        
        for row in csv_reader:
            ts = float(row['ts'])
            
            # 如果仍在当前时间窗口内
            if ts < current_window_end:
                row_count += 1
                total_pkt += int(row['pkt'])
                total_byt += int(row['byt'])
            else:
                # 写入当前窗口的统计结果
                csv_writer.writerow([
                    start_ts,
                    current_window_end - 1,  # 窗口结束时间减1
                    row_count,
                    total_pkt,
                    total_byt
                ])
                
                # 重置统计变量，处理可能的时间间隔
                start_ts = current_window_end
                current_window_end = start_ts + time_window
                row_count = 0
                total_pkt = 0
                total_byt = 0
                
                # 处理当前行（可能跨越多个时间窗口）
                while ts >= current_window_end:
                    # 写入空窗口
                    csv_writer.writerow([
                        start_ts,
                        current_window_end - 1,
                        0,
                        0,
                        0
                    ])
                    start_ts = current_window_end
                    current_window_end += time_window
                
                # 添加当前行到新窗口
                row_count = 1
                total_pkt = int(row['pkt'])
                total_byt = int(row['byt'])
        
        # 写入最后一个时间窗口的统计结果
        if row_count > 0:
            csv_writer.writerow([
                start_ts,
                current_window_end - 1,
                row_count,
                total_pkt,
                total_byt
            ])

if __name__ == "__main__":
    # 设置命令行参数解析
    parser = argparse.ArgumentParser(description='CSV文件周期性统计工具')
    parser.add_argument('-i', '--input', required=True, help='输入CSV文件名')
    parser.add_argument('-o', '--output', required=True, help='输出CSV文件名')
    parser.add_argument('-w', '--window', type=int, required=True, 
                       help='统计时间窗口大小（纳秒）')
    
    args = parser.parse_args()
    
    print(f"开始处理: 输入文件={args.input}, 输出文件={args.output}, 时间窗口={args.window}纳秒")
    process_csv(args.input, args.output, args.window)
    print(f"处理完成，结果已保存至: {args.output}")
