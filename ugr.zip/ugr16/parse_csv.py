
import csv
import os

# 定义标签转换映射
label_mapping = {
    'background': '0',
    'blacklist': '1'
}

# 定义协议转换映射
proto_mapping = {
    'tcp': '0',
    'udp': '1',
    'icmp': '2',
    'gre': '3'  # 添加GRE协议
}

input_filename = 'raw.csv'
output_filename = 'output.csv'

# 修正列索引（现在是0-9共10列）
COLUMNS = {
    'srcip': 0,
    'dstip': 1,
    'srcport': 2,
    'dstport': 3,
    'proto': 4,
    'ts': 5,
    'td': 6,    # 时间持续时间
    'pkt': 7,   # pkt在第8列（索引7）
    'byt': 8,   # byt在第9列（索引8）
    'type': 9   # label在第10列（索引9）
}

print(f"当前工作目录: {os.getcwd()}")
print(f"输入文件存在: {os.path.exists(input_filename)}")

with open(input_filename, 'r') as infile, open(output_filename, 'w', newline='') as outfile:
    csv_reader = csv.reader(infile)
    csv_writer = csv.writer(outfile)

    # 写入新文件的表头
    csv_writer.writerow(['srcip', 'dstip', 'srcport', 'dstport', 'proto', 'ts', 'pkt', 'byt', 'label'])

    # 跳过原始文件的表头行
    try:
        header = next(csv_reader)
        print(f"文件头: {header}")
    except StopIteration:
        print("错误: 输入文件为空")
        exit(1)

    processed_rows = 0
    skipped_rows = 0

    for row_num, row in enumerate(csv_reader, 2):  # 从第2行开始计数
        if len(row) < 10:  # 现在检查10列而不是11列
            print(f"跳过行 {row_num}: 列数不足 ({len(row)}列)")
            skipped_rows += 1
            continue

        # 提取所需字段
        srcip = row[COLUMNS['srcip']]
        dstip = row[COLUMNS['dstip']]
        srcport = row[COLUMNS['srcport']]
        dstport = row[COLUMNS['dstport']]
        ts = row[COLUMNS['ts']]
        pkt = row[COLUMNS['pkt']]
        byt = row[COLUMNS['byt']]

        # 转换协议类型（proto列）- 添加.lower()处理大小写
        raw_proto = row[COLUMNS['proto']].strip().lower()
        proto = proto_mapping.get(raw_proto, '4')  # 默认值改为4表示未知协议

        # 转换标签 - 添加.lower()处理大小写
        raw_label = row[COLUMNS['type']].strip().lower()
        label = label_mapping.get(raw_label, '2')  # 默认值2表示未知类型

        # 写入新行
        csv_writer.writerow([srcip, dstip, srcport, dstport, proto, ts, pkt, byt, label])
        processed_rows += 1

    print(f"处理完成: 共处理 {processed_rows} 行, 跳过 {skipped_rows} 行")

print(f"文件处理完成，结果已保存至: {output_filename}")
