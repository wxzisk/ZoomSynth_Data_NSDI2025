import csv

input_filename = 'output_new.csv'
output_filename = 'input_stage_5.csv'
window_size = 10  # 1秒(10^9纳秒)的时间窗口

with open(input_filename, 'r') as infile, open(output_filename, 'w', newline='') as outfile:
    csv_reader = csv.reader(infile)
    csv_writer = csv.writer(outfile)
    
    # 写入输出文件的表头
    csv_writer.writerow(['start_ts', 'end_ts', 'parse_raw_file.pyrow_count', 'total_bytes'])
    
    # 跳过输入文件的表头
    header = next(csv_reader)
    
    # 读取第一行获取起始时间戳
    try:
        first_row = next(csv_reader)
        # 处理带小数的时间戳值
        base_ts = int(float(first_row[5]))  # 先转浮点数再转整数
    except StopIteration:
        print("警告：输入文件为空（只有表头）")
        exit()
    
    # 初始化第一个时间窗口
    current_window_start = base_ts
    current_window_end = base_ts + window_size
    row_count = 1
    # 处理带小数的字节值
    total_bytes = int(float(first_row[6]))  # byt在第6列(索引6)
    
    for row in csv_reader:
        if len(row) < 7:  # 确保行有足够列
            continue
            
        try:
            # 处理可能带小数的时间戳
            ts = int(float(row[5]))  # 当前行的时间戳
            # 处理可能带小数的字节值
            byte_val = int(float(row[6]))  # 当前行的字节数
        except (ValueError, IndexError):
            continue  # 跳过格式错误的数据行
        
        # 检查是否仍在当前时间窗口内
        if ts < current_window_end:
            row_count += 1
            total_bytes += byte_val
        else:
            # 输出当前时间窗口的统计结果
            csv_writer.writerow([current_window_start, current_window_end, row_count, total_bytes])
            
            # 计算需要跳过的空窗口数
            skip_windows = (ts - current_window_end) // window_size
            
            # 输出所有空窗口(值为0)
            for i in range(skip_windows):
                empty_start = current_window_end + i * window_size
                empty_end = empty_start + window_size
                csv_writer.writerow([empty_start, empty_end, 0, 0])
            
            # 设置新的时间窗口
            current_window_start = current_window_end + skip_windows * window_size
            current_window_end = current_window_start + window_size
            
            # 重置统计计数器，包含当前行
            row_count = 1
            total_bytes = byte_val
    
    # 写入最后一个时间窗口的统计结果
    csv_writer.writerow([current_window_start, current_window_end, row_count, total_bytes])

print(f"统计完成，结果已保存至: {output_filename}")
