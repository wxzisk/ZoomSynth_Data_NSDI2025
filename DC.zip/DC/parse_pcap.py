import dpkt
import socket
import argparse

parser = argparse.ArgumentParser(description="Extract packet information from pcap file.")
parser.add_argument("input_pcap", help="Input pcap file path")
parser.add_argument("output_file", help="Output text file path")
args = parser.parse_args()

pcap_file = args.input_pcap
output_file = args.output_file

with open(pcap_file, 'rb') as f, open(output_file, 'w') as f_out:
    # 尝试使用 pcapng 解析器
    try:
        pcap = dpkt.pcapng.Reader(f)
        # pcapng 返回 (ts, buf) 元组
        is_pcapng = True
    except (ValueError, dpkt.dpkt.NeedData):
        # 如果 pcapng 解析失败，回退到 pcap 解析器
        f.seek(0)
        pcap = dpkt.pcap.Reader(f)
        is_pcapng = False
    
    first_ts = None
    
    # 统一处理两种格式
    for record in pcap:
        # 两种解析器都返回 (ts, buf) 元组
        if isinstance(record, tuple) and len(record) == 2:
            ts, buf = record
        else:
            # 如果不是元组格式，跳过这个记录
            continue
        
        if first_ts is None:
            first_ts = ts
        
        relative_ts = ts - first_ts
        
        try:
            eth = dpkt.ethernet.Ethernet(buf)
            if isinstance(eth.data, dpkt.ip.IP):
                ip = eth.data
                src_ip = socket.inet_ntoa(ip.src)
                dst_ip = socket.inet_ntoa(ip.dst)
                protocol = ip.p
                
                if isinstance(ip.data, dpkt.tcp.TCP):
                    src_port = ip.data.sport
                    dst_port = ip.data.dport
                elif isinstance(ip.data, dpkt.udp.UDP):
                    src_port = ip.data.sport
                    dst_port = ip.data.dport
                else:
                    src_port = 0
                    dst_port = 0
                
                # 输出相对时间（保留6位小数）
                f_out.write(f'{relative_ts:.6f},{len(buf)},{src_ip},{dst_ip},{src_port},{dst_port},{protocol}\n')
        except Exception as e:
            # 处理解析错误，跳过无法解析的数据包
            print(f"Error processing packet: {e}")
            continue
